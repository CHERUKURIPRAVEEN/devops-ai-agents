#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[[ $(uname -m) == x86_64 ]] || { echo 'x86_64 required'; exit 1; }
. /etc/os-release
[[ $ID == ubuntu && $VERSION_ID == 24.04 ]] || { echo 'Ubuntu 24.04 required'; exit 1; }
command -v ansible-playbook >/dev/null
sudo -v
ansible-playbook -i localhost, -c local --syntax-check playbook.yml
ansible-playbook -i localhost, -c local --become playbook.yml
