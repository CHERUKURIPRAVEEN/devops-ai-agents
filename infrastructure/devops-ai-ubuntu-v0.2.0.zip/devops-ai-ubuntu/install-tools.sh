#!/usr/bin/env bash
set -euo pipefail
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cd "$work"
fetch() { curl --fail --silent --show-error --location --retry 3 -O "$1"; }
if ! command -v terraform >/dev/null; then
  v=1.12.2; f=terraform_${v}_linux_amd64.zip; base=https://releases.hashicorp.com/terraform/$v
  fetch "$base/$f"; fetch "$base/terraform_${v}_SHA256SUMS"
  awk -v f="$f" '$2==f {print}' "terraform_${v}_SHA256SUMS" > verify; test -s verify; sha256sum -c verify
  unzip -o "$f" terraform; install -m 0755 terraform /usr/local/bin/terraform; echo 'terraform installed'
fi
if ! command -v tflint >/dev/null; then
  v=v0.58.1; f=tflint_linux_amd64.zip; base=https://github.com/terraform-linters/tflint/releases/download/$v
  fetch "$base/$f"; fetch "$base/checksums.txt"
  awk -v f="$f" '$2==f || $2=="*"f {print}' checksums.txt > verify; test -s verify; sha256sum -c verify
  unzip -o "$f" tflint; install -m 0755 tflint /usr/local/bin/tflint; echo 'tflint installed'
fi
