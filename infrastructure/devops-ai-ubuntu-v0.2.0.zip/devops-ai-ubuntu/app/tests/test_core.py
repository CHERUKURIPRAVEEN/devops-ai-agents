import unittest
from core import route, AGENTS
class RoutingTest(unittest.TestCase):
    def test_routes(self):
        for prompt,expected in [('terraform plan','Terraform'),('kubectl pods','Kubernetes'),('AWS EC2','AWS'),('hello','General')]:
            self.assertEqual(route(prompt),expected)
    def test_registration(self): self.assertEqual(len(AGENTS),4)
