import httpx, psutil
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from core import AGENTS, MODEL, chat, history
app=FastAPI(title='DevOps AI Platform',version='0.2.0')
class Request(BaseModel):
    prompt:str=Field(min_length=1,max_length=6000)
    agent:str='Auto'
@app.get('/health')
def health():
    ready=False
    try:
        r=httpx.get('http://127.0.0.1:11434/api/tags',timeout=3); r.raise_for_status(); ready=any(m['name']==MODEL for m in r.json()['models'])
    except Exception: pass
    return {'api':'ok','model':MODEL,'model_ready':ready,'memory_percent':psutil.virtual_memory().percent,'cpu_percent':psutil.cpu_percent(),'agents':AGENTS}
@app.get('/audit')
def audit(): return history()
@app.post('/chat')
def ask(req:Request):
    if req.agent not in ['Auto',*AGENTS]: raise HTTPException(400,'Unknown agent')
    try: return chat(req.prompt,req.agent)
    except RuntimeError: raise HTTPException(409,'Agent busy or unavailable')
    except Exception: raise HTTPException(503,'Inference failed; check Ollama and logs')

from terraform_agent import run_check, plan_summary
class ScanRequest(BaseModel):
    path:str=Field(min_length=1,max_length=4096)
    task:str
    trusted:bool=False
@app.post('/terraform/scan')
def scan(req:ScanRequest):
    if not req.trusted: raise HTTPException(400,'Trusted workspace confirmation required')
    try: return run_check(req.path,req.task)
    except (ValueError,OSError) as e: raise HTTPException(400,str(e))
    except RuntimeError as e: raise HTTPException(409,str(e))
@app.post('/terraform/plan-summary')
def summarize_plan(data:dict):
    try: return plan_summary(data)
    except (ValueError,KeyError,TypeError): raise HTTPException(400,'Invalid plan JSON')
