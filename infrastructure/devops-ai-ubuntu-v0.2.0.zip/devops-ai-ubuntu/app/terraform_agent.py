"""Explicit, local-only Terraform checks on trusted workspaces."""
import os, shutil, subprocess, threading, json
from pathlib import Path
from core import audit
ROOT=Path('/var/lib/devopsai/workspaces').resolve()
LOCK=threading.Lock()
TOOLS={'format':('terraform','fmt','-check','-recursive'), 'validate':('terraform','validate','-no-color'), 'lint':('tflint','--no-color'), 'security':('checkov','--framework','terraform','--directory','.','--download-external-modules','false','--output','cli')}
def workspace(value):
    p=Path(value).expanduser().resolve(strict=True)
    if not p.is_dir() or p==ROOT or not p.is_relative_to(ROOT): raise ValueError('Choose a project directory inside /var/lib/devopsai/workspaces')
    if not any(p.glob('*.tf')): raise ValueError('No root Terraform files found')
    return p

def run_check(path, task):
    if task not in TOOLS: raise ValueError('Unsupported task')
    p=workspace(path)
    args=TOOLS[task]; exe=shutil.which(args[0])
    if task=='security':
        candidate=Path('/opt/devops-ai-platform/checkov-venv/bin/checkov')
        exe=str(candidate) if candidate.is_file() else None
    if not exe: raise ValueError(f'{args[0]} not installed')
    if not LOCK.acquire(False): raise RuntimeError('Scan already running')
    try:
        # Do not pass cloud credentials or CLI override variables to tools.
        env={k:os.environ[k] for k in ('HOME','PATH','TMPDIR','LANG','LC_ALL') if k in os.environ}
        env.update(TF_IN_AUTOMATION='1',CHECKOV_SKIP_DOWNLOAD='true',CHECKOV_OFFLINE='true',AWS_EC2_METADATA_DISABLED='true')
        result=subprocess.run([exe,*args[1:]],cwd=p,env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True,errors='replace',timeout=90)
        audit('Terraform',f'{task}: exit {result.returncode}')
        return {'task':task,'exit_code':result.returncode,'output':(result.stdout+'\n'+result.stderr)[-16000:]}
    except subprocess.TimeoutExpired:
        audit('Terraform',f'{task}: timeout'); raise RuntimeError('Scan timed out')
    finally: LOCK.release()

def plan_summary(data):
    if not isinstance(data,dict) or not isinstance(data.get('resource_changes'),list): raise ValueError('Expected terraform show -json output containing resource_changes')
    counts={}; rows=[]
    for item in data['resource_changes']:
        actions=item['change']['actions']; key=' / '.join(actions); counts[key]=counts.get(key,0)+1
        if len(rows)<500: rows.append({'address':item['address'],'actions':key})
    return {'counts':counts,'resources':rows,'truncated':len(data['resource_changes'])>500}
