import streamlit as st
import httpx
BASE='http://127.0.0.1:8000'
st.set_page_config(page_title='DevOps AI Platform',page_icon='⚙️',layout='wide')
st.title('DevOps AI Platform')
st.caption('EC2 edition · v0.2.0 · local Terraform checks')
try:
    r=httpx.get(BASE+'/health',timeout=5); r.raise_for_status(); h=r.json()
except Exception:
    st.error('Backend unavailable. Check systemd service status'); st.stop()
a,b,c=st.columns(3); a.metric('AI model','Ready' if h['model_ready'] else 'Unavailable'); b.metric('Memory',f"{h['memory_percent']}%"); c.metric('CPU',f"{h['cpu_percent']}%")
page=st.sidebar.radio('Navigation',['AI Chat','Terraform Tools','Agents','Audit logs'])
if page=='Agents':
    for name,desc in h['agents'].items(): st.subheader(name); st.write(desc); st.caption('Local checks available in Terraform Tools' if name=='Terraform' else 'Advisory only — no live tools')
elif page=='Terraform Tools':
    import json
    st.subheader('Terraform workspace checks')
    st.warning('Use only trusted repositories and plugins. Tools are not sandboxed. Scan output may contain sensitive data; do not paste it into chat without review.')
    path=st.text_input('Absolute path under /var/lib/devopsai/workspaces')
    trusted=st.checkbox('I trust this repository, its configuration and installed plugins')
    task=st.selectbox('Check',['format','validate','lint','security'])
    st.caption('Validate requires an initialized workspace; lint requires preinstalled plugins. No init, plan, apply or destroy is executed.')
    if st.button('Run check',disabled=not trusted or not path.strip()):
        try:
            with st.spinner('Running local check…'):
                r=httpx.post(BASE+'/terraform/scan',json={'path':path,'task':task,'trusted':trusted},timeout=100); r.raise_for_status(); st.session_state['scan_result']=r.json()
        except Exception as e: st.error(str(e))
    if 'scan_result' in st.session_state:
        result=st.session_state['scan_result']; st.write(f"{result['task']} — exit code {result['exit_code']}"); st.code(result['output'])
    st.divider(); st.subheader('Existing plan JSON summary')
    st.caption('Only resource addresses and actions are displayed; do not upload confidential plans.')
    f=st.file_uploader('Local plan JSON',type=['json'])
    if f and st.button('Summarize plan'):
        try:
            if f.size>10_000_000: raise ValueError('File exceeds 10 MB')
            r=httpx.post(BASE+'/terraform/plan-summary',json=json.load(f),timeout=30); r.raise_for_status(); st.json(r.json()['counts']); st.dataframe(r.json()['resources'])
        except Exception as e: st.error(str(e))
elif page=='Audit logs':
    try: st.dataframe([dict(zip(['UTC time','Agent','Status'],r)) for r in httpx.get(BASE+'/audit',timeout=5).json()])
    except Exception: st.error('Audit unavailable')
else:
    agent=st.selectbox('Agent',['Auto',*h['agents']]); st.warning('Do not enter secrets or sensitive production data. Model responses may be incorrect.')
    prompt=st.text_area('Ask a DevOps question',max_chars=6000)
    if st.button('Run task',disabled=not h['model_ready'] or not prompt.strip()):
        with st.spinner('Running local inference…'):
            try:
                r=httpx.post(BASE+'/chat',json={'prompt':prompt,'agent':agent},timeout=190); r.raise_for_status(); st.subheader(r.json()['agent']); st.markdown(r.json()['answer'])
            except Exception: st.error('Task failed. Check systemd service logs.')
