#!/usr/bin/env bash
set -euo pipefail
systemctl is-active ollama devops-ai-api devops-ai-dashboard
curl -fsS http://127.0.0.1:8000/health; echo
curl -fsS http://127.0.0.1:8501/_stcore/health; echo
ollama list
terraform version
tflint --version
/opt/devops-ai-platform/checkov-venv/bin/checkov --version
